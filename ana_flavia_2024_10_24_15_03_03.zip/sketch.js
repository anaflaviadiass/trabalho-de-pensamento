let campoIdade;
let campoFantasia;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de musica");
  createSpan("Sua idade:");
  campoIdade = createInput("16");
  campoFantasia = createCheckbox("Gosta de musica");
}


function draw() {
    background("white");
    let idade = campoIdade.value();
    let gostaDeMusica = campoMusica.checked();
    let recomendacao = geraRecomendacao(idade, gostaDeMusica);

    fill(color(76, 0, 115));
    textAlign(CENTER, CENTER);
    textSize(38);
    text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeMusica) {
    if (idade >= 10) {
        if (idade >= 14) {
            return "chuva de arroz";
        } else {
            if (gostaDeMusica) {
                return "te vivo";
            } else {
                return "te esperando;
            }
        }
    } else {
        if (gostaDeMusica) {
            return "boa memoria";
        } else {
            return "agua com açucar";
        }
    }
}
